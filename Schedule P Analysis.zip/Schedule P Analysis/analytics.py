"""Reserve development analytics for Schedule P Part 2 data (net incurred loss & DCC, $000).

Input: tidy DataFrame `tidy` with one row per (vintage, row_label, eval_year) cell:
    cls        str    class name, e.g. "OL Occurrence"
    vintage    int    year of the annual file (= latest evaluation year in that file)
    ay         str|int  accident year, or "PRIOR"
    eval_year  int    calendar year-end at which `incurred` is measured
    incurred   float  net incurred loss + DCC ($000)
    nep        float  net earned premium of that accident year ($000); NaN for PRIOR

Sign convention: development > 0 = adverse (reserve increase); < 0 = favourable (release).
"""
import numpy as np
import pandas as pd


def one_year_dev(tidy: pd.DataFrame) -> pd.DataFrame:
    """Calendar-year (vintage) one-year development per row, taken from WITHIN each vintage:
    dev(row, Y) = incurred(row, eval=Y) - incurred(row, eval=Y-1), both from the vintage-Y file.
    Using one vintage per CY keeps PRIOR consistent (its AY membership changes between files)."""
    cur = tidy[tidy.eval_year == tidy.vintage][["cls", "vintage", "ay", "incurred", "nep"]].rename(columns={"incurred": "inc_now"})
    prev = tidy[tidy.eval_year == tidy.vintage - 1][["cls", "vintage", "ay", "incurred"]].rename(columns={"incurred": "inc_prev"})
    d = cur.merge(prev, on=["cls", "vintage", "ay"], how="inner")
    d["dev"] = d.inc_now - d.inc_prev
    # age of an AY at the evaluation date (end of AY = age 1); PRIOR has no age
    d["age_now"] = [np.nan if a == "PRIOR" else v - int(a) + 1 for a, v in zip(d.ay, d.vintage)]
    return d


def cy_summary(dev: pd.DataFrame, tidy: pd.DataFrame) -> pd.DataFrame:
    """Total one-year (prior-year) development by calendar year, in $000 and as % of current-year NEP."""
    out = dev.groupby(["cls", "vintage"]).dev.sum().rename("pyd").reset_index()
    nep_cy = (tidy[(tidy.ay != "PRIOR") & (tidy.ay.astype(str) == tidy.vintage.astype(str))]
              .drop_duplicates(["cls", "vintage"])[["cls", "vintage", "nep"]].rename(columns={"nep": "nep_cy"}))
    out = out.merge(nep_cy, on=["cls", "vintage"], how="left")
    out["pyd_pct_nep"] = out.pyd / out.nep_cy
    prior = dev[dev.ay == "PRIOR"][["cls", "vintage", "dev"]].rename(columns={"dev": "pyd_prior_row"})
    return out.merge(prior, on=["cls", "vintage"], how="left")


def dev_by_age(dev: pd.DataFrame) -> pd.DataFrame:
    """Development as % of the AY's own NEP, by age transition (age_now-1 -> age_now)."""
    d = dev[dev.ay != "PRIOR"].copy()
    d["dev_pct_ay_nep"] = d.dev / d.nep
    g = d.groupby(["cls", "age_now"]).dev_pct_ay_nep
    return g.agg(n="count", mean="mean", median="median", sd="std", min="min", max="max").reset_index()


def ay_cy_matrix(dev: pd.DataFrame, cls: str) -> pd.DataFrame:
    """AY x calendar-year matrix of development as % of AY NEP (heat-map input)."""
    d = dev[(dev.cls == cls) & (dev.ay != "PRIOR")].copy()
    d["pct"] = d.dev / d.nep
    return d.pivot(index="ay", columns="vintage", values="pct")


def series_stats(cy: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for c, g in cy.groupby("cls"):
        x = g.sort_values("vintage").pyd_pct_nep.dropna()
        rows.append(dict(cls=c, n=len(x), mean=x.mean(), sd=x.std(ddof=1), adverse_share=(x > 0).mean(),
                         lag1=x.autocorr(1) if len(x) > 3 else np.nan))
    return pd.DataFrame(rows)
