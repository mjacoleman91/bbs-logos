# Schedule P reserve-development extractor: spec for VS Code / Copilot

(Assumes "Schedule B" in the request means **Schedule P**, the US statutory loss-development schedule.)

## 0. Paste this into Copilot first

> Build a Python package in this folder that reads W. R. Berkley Schedule P Part 2 Excel supplements, one file per
> year per class of business, and produces reserve release / increase tables. Follow
> SCHEDULE_P_RESERVE_DEVELOPMENT_SPEC.md exactly. Do NOT hard-code cell addresses: find each block by its text labels.
> Use `analytics.py` as the reference for the maths. Write the parser and CLI around it. It must pass the tests in
> section 7 on the OL Occurrence files before you touch any other class. Stop and report if any reconciliation check fails.

## 1. Purpose

Schedule P is the statutory annual-statement schedule that shows, by line of business and accident year (AY), how
**net incurred loss and defence cost (DCC)** has developed over 10 years. Incurred includes booked IBNR, so a change in
incurred is a **reserve release (negative) or reserve increase (positive)**.

We use it for three things:
1. **Reserve release / increase pattern by class**: calendar-year prior-year development (PYD) as % of net earned premium.
2. **Development by AY age**: at what ages reserves tend to move, and by how much.
3. **Benchmarks for the CV model**: the empirical one-year development volatility, the development CV by age (reserve CV), and
   the ULR volatility. These justify the parameters in the reserve and future-year CV workbook.

Limits (keep these in the report): data is **net of reinsurance**, **accident-year basis**, **booked** (not independent) estimates,
**$000**. Lifson data is gross and underwriting-year. Do not read these numbers as pure statistical noise: they include reserving behaviour.

## 2. Where to get the data

Page: https://ir.berkley.com/financials/annual-reports/default.aspx
Files are hosted at `https://s21.q4cdn.com/514440399/files/doc_financials/{year}/ar/{file}`.

| Class | Years available | Notes |
|---|---|---|
| Other Liability Occurrence | 2015 to 2025 | 11 files; 2015 is `.xls` |
| Workers' Compensation | 2015 to 2024 | 2015 to 2017 are `.xls` |
| Reinsurance Non-Proportional Assumed Liability | 2018 to 2025 | direct benchmark for casualty XoL |
| Berkley Insurance Company Schedule P (general) | 2024 | whole entity, not by sub-class |

Each file holds **10 accident years** plus a **PRIOR** row, so the annual files chain together into about 20 AYs
(OL Occ: AY 2006 to 2025).

File names (OL Occurrence; the same page lists the other classes):
```
2025 OL-Occ-Supplement-2025-Exhibits-FINAL.xlsx
2024 OL-Occ-Supplement-Exhibits-2024.xlsx
2023 Supplementary-Schedule-P-Information-2023-Other-Liability-Occurrence.xlsx
2022 supplementary-schedule-p-information-2022-other-liability-occurrence.xlsx
2021 OL-Occ-Supplement-Final-2021.xlsx
2020 OL-Occ-Supplement-2020-Final.xlsx
2019 OL-Occ-Supplement-2019-Final.xlsx
2018 OL-Occ-Supplement.xlsx
2017 OL-Occ-Supplement-2017.xlsx
2016 OL-Occ-Supplement-Exhibits-2016.xlsx
2015 OL-Occ-Supplement-2015.xls
```
Workers' Compensation: `WC-Supplement-2024-Exhibits.xlsx`, `Supplementary-Schedule-P-Information-2023-Workers-Compensation.xlsx`, ... (see page).
NP Assumed Liability: `ReLiab-Supplement-2025-Exhibits-FINAL.xlsx`, `ReLiab-Supplement-2024-Exhibits.xlsx`, ... (see page).

The CLI downloads missing files into `data/raw/<class>/<year>.<ext>` from Berkley's official file host.
The 2015 OL Occurrence URL ends in `.xls`, but its payload is an XLSX workbook; the reader detects the workbook
format from its contents rather than assuming it from the extension. The downloaded source files are retained unchanged.
The original supplements have now been inspected. The aggregate `Filed Total` sheet contains the target Other Liability
Occurrence triangles, premium table, cumulative paid triangle, and bulk-and-IBNR triangle. Layout and reconciliation checks
still run on each file so a later structural change fails explicitly.

## 3. What is in a Part 2 block (one per annual file)

- Title row: "INCURRED NET LOSSES AND DEFENSE AND COST CONTAINMENT EXPENSES REPORTED AT YEAR END (000 omitted)".
- Header rows: development year 1..10, then calendar year labels (e.g. 2006..2015). Column j = evaluation at year-end 2006+j-1.
- Row labels: `PRIOR`, then 10 accident years, then a `Totals` row.
- Cells not yet observed hold `XXX` (treat as missing).
- **Development columns** (11 and 12): `One Year` and `Two Year`. One Year = latest diagonal minus the previous diagonal.
  Two Year = latest minus two diagonals ago. `Totals` of One Year = calendar-year PYD.
- **Premium columns**: Direct and Assumed, Ceded, Net (earned, by AY). Net = DA minus Ceded.

## 4. Definitions

- Evaluation year E = calendar year-end of the cell. Age of an AY at E = E - AY + 1 (end of AY = age 1).
- `dev(row, Y) = incurred(row, eval=Y) - incurred(row, eval=Y-1)`, **taken from the vintage Y file only**.
  PRIOR changes membership between files, so never stitch PRIOR across vintages.
- Sign: **> 0 adverse (reserve increase)**; **< 0 favourable (release)**.
- `PYD(Y)` = sum of `dev` over all rows (including PRIOR) in the vintage Y file = `Totals` of the One Year column.
- `PYD % NEP` = PYD(Y) / net earned premium of AY Y (the current-year premium).
- Dev by age = dev(a, Y) / NEP of AY a, grouped by age after the move (age_now = Y - a + 1).

## 5. Build steps

1. **Config** (`config.yaml`): per class, the folder, vintage-to-file map, source sheet by year where needed, units (000),
   and any source-label corrections.
2. **Reader**: detect XLSX payloads (including the legacy 2015 `.xls` extension) and support actual `.xls` files with xlrd.
   The class config identifies the aggregate sheet; block locations are found by text labels, not cell addresses.
3. **Block locator**: find the cell containing "INCURRED NET LOSSES AND DEFENSE AND COST", then read the header, the `PRIOR` row, AY rows
   (4-digit years) and the `Totals` row below it. Map development columns to calendar years from the header labels.
4. **Tidy table** (schema at the top of `analytics.py`): `cls, vintage, ay, eval_year, incurred, nep`. Convert `XXX` to missing.
   Keep PRIOR as `ay = "PRIOR"` with `nep = NaN`.
5. **Reconciliation checks per block (hard fail):**
   - Recomputed `One Year` per row equals the published One Year column (tolerance: +-2, rounding).
   - Sum of rows equals the published `Totals` (tolerance +-5).
   - Net premium = Direct/Assumed minus Ceded (tolerance +-2).
   - AY rows are 10 consecutive years ending at the vintage year.
6. **Overlap check across vintages:** for the same AY and eval year, incurred, paid, and bulk-and-IBNR values from
   different files are compared. Report differences (restatements are possible; flag, do not silently overwrite).
7. **Analytics:** call `one_year_dev`, `cy_summary`, `dev_by_age`, `ay_cy_matrix`, `series_stats` from `analytics.py`.
8. **Outputs** to `out/<class>/`:
   - `tidy.csv`
   - `pyd_by_calendar_year.csv` (PYD $000, PYD % NEP, PRIOR-row PYD)
   - `dev_by_age.csv` (n, mean, median, SD, min, max, % of AY NEP)
   - `ay_by_cy_matrix.csv`
   - `summary.xlsx` with source sheets, cell references, linked calculation formulas, reconciliation checks, and charts
   - `source_manifest.csv` with official URLs and SHA-256 hashes for reproducible provenance
   - `pyd_pct_nep.png` (bar chart by calendar year), `ay_cy_heatmap.png`, and `paid_to_incurred_by_age.png`
   - overlap/restatement, series-statistics, and early-versus-recent period comparison CSVs
   - Part 3 paid-to-incurred by-age analysis as descriptive supplementary context, not a pure settlement assumption
   - `out/class_comparison.csv` and `out/class_comparison.png` when `--all` is used. Comparative metrics include
     a common 2018-2024 period and an aligned 2021-2024 recent period; always consider the displayed sample counts.
9. **CLI:** `python -m schedp run --class "OL Occurrence"` (downloads missing sources automatically), `fetch`, and `--all`.

## 6. Class coverage and source quirks

The current configuration covers all three classes: OL Occurrence (2015-2025), Workers' Compensation (2015-2024), and
Reinsurance Non-Proportional Assumed Liability (2018-2025). Workers' Compensation's older files use `Total WC` and the
later files use `Filed Total`; Reinsurance uses `Reins Liab` through 2021 and `Filed Total` from 2022 onward. The
2019 Reinsurance source labels the AY 2018 row as 2017 in Part 2, Part 3, and Part 4. The parser corrects those three
labels in memory using explicit row-level config while retaining the original source file and documenting the correction.
Older WC files label PRIOR as `PRIOR....`; the reader recognizes this as the PRIOR row.

The archived official links are downloaded from the annual reports page. Each class receives its own outputs and
validation run. Cross-class percentages are descriptive and must not be averaged into a combined rate without premium
weighting and a clear rationale. The 2021-2025 period contains only four WC years because WC ends in 2024; compare
classes on the same calendar years when interpreting differences.

## 7. Validation fixtures (OL Occurrence, $000, from the analysis workbook)

| Vintage | PYD total (One Year) | NEP of AY = vintage | PYD % NEP |
|---|---|---|---|
| 2015 | -16,272 | 1,016,952 | -1.6% |
| 2016 | 9,878 | 1,135,092 | 0.9% |
| 2017 | -19,879 | 1,206,902 | -1.6% |
| 2018 | 17,435 | 1,269,413 | 1.4% |
| 2019 | 84,142 | 1,382,433 | 6.1% |
| 2020 | 37,243 | 1,510,654 | 2.5% |
| 2021 | 15,879 | 1,773,092 | 0.9% |
| 2022 | 49,384 | 2,157,182 | 2.3% |
| 2023 | 196,663 | 2,485,229 | 7.9% |
| 2024 | 270,987 | 2,896,208 | 9.4% |
| 2025 | 406,149 | 3,174,509 | 12.8% |

Expected series stats (n = 11): mean 3.7%, SD 4.7%, adverse in 9 of 11 years, lag-1 autocorrelation 0.74.
Expected 2015 PRIOR-row One Year = +12,776. AY2006 one-year development in vintage 2015 = +3,820 (424,865 - 421,045).
Expected dev by age (mean % of AY NEP): age 2 about -1.4%, ages 4 to 6 about +2%, age 9 to 10 about 0%.

Acceptance: all checks in section 5 pass, and the PYD column matches the table within +-5 (published values are rounded).

## 8. Pitfalls

- Units are $000. Do not mix with Lifson $m.
- `PRIOR` is not an accident year. Exclude it from AY-level tables and age statistics.
- Do not average percentages across classes without weighting by premium.
- Incurred includes IBNR, so development is reserving behaviour, not outcome noise. Immature AYs are often booked at a flat a-priori loss ratio.
- Basis is net of reinsurance, AY. Say so in every chart title.
- A file with a changed layout must fail loudly, not guess.
- The WC Part 4 bulk-and-IBNR overlap checks flag large differences across source vintages. These are retained as
  restatement/definition-change flags and should be investigated separately from Part 2 incurred development.

## 9. How this feeds the CV model

- **One-year development volatility**: SD of `PYD % NEP` (or, if paid/case data is available, PYD as % of opening net reserves).
  Compare with the model's one-year ÷ run-off ratio (about 0.5 for casualty in the dummy). Use this to calibrate it.
- **Reserve CV by age**: dev by age (SD by age, and the ratio of cumulative age-1 to 10 development).
- **Systematic risk**: the lag-1 autocorrelation of PYD % NEP supports a high correlation across accident years for casualty.
- **Release/increase pattern**: shows whether the benchmark is biased. For OL Occ, recent years are strongly adverse, so a
  mean-zero development assumption is not supported by the data.
- **Part 3 / Part 4**, if present in a file, add paid and case/IBNR splits, which would give a reported pattern and a paid
  pattern (p and g) for the model. Part 2 alone cannot; it is booked incurred including IBNR.

## 10. Files in this folder

- `analytics.py`: reference implementation of the maths, tested on the OL Occurrence data (fixtures above reproduced).
- This spec.
- `schedp/`: source reader, validation pipeline, analysis, and formula-linked workbook generator.
- `config.yaml`: official source filenames and aggregate sheet configuration.
- `data/raw/`: downloaded official supplements for all three classes; `out/`: class reports and the cross-class comparison.
