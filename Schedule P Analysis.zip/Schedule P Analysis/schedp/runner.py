from __future__ import annotations

from hashlib import sha256
from pathlib import Path
from urllib.request import urlopen
import argparse
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import yaml

from analytics import ay_cy_matrix, cy_summary, dev_by_age, one_year_dev, series_stats
from schedp.extractor import VintageData, extract_vintage
from schedp.report import write_outputs


ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = ROOT / "config.yaml"
SOURCE_BASE = "https://s21.q4cdn.com/514440399/files/doc_financials"

FIXTURES = {
    2015: ( -16272, 1016952),
    2016: (   9878, 1135092),
    2017: ( -19879, 1206902),
    2018: (  17435, 1269413),
    2019: (  84142, 1382433),
    2020: (  37243, 1510654),
    2021: (  15879, 1773092),
    2022: (  49384, 2157182),
    2023: ( 196663, 2485229),
    2024: ( 270987, 2896208),
    2025: ( 406149, 3174509),
}


def _read_config() -> dict:
    with CONFIG_PATH.open(encoding="utf-8") as file:
        return yaml.safe_load(file)


def _source_path(class_name: str, vintage: int, filename: str) -> Path:
    extension = Path(filename).suffix
    return ROOT / "data" / "raw" / class_name / f"{vintage}{extension}"


def _source_url(vintage: int, filename: str) -> str:
    return f"{SOURCE_BASE}/{vintage}/ar/{filename}"


def _download(url: str, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with urlopen(url, timeout=60) as response:
        payload = response.read()
    if not payload.startswith((b"PK", bytes.fromhex("D0CF11E0A1B11AE1"))):
        raise ValueError(f"Downloaded source did not look like an Excel workbook: {url}")
    path.write_bytes(payload)
    print(f"Downloaded {path.relative_to(ROOT)}")


def _load_vintages(
    class_name: str, class_config: dict, download_missing: bool
) -> list[VintageData]:
    result = []
    for year_text, filename in sorted(class_config["years"].items()):
        vintage = int(year_text)
        path = _source_path(class_name, vintage, filename)
        url = _source_url(vintage, filename)
        if not path.exists():
            if not download_missing:
                raise FileNotFoundError(f"Missing source supplement: {path}")
            _download(url, path)
        content = path.read_bytes()
        sheet_config = class_config.get("sheet", "Filed Total")
        if isinstance(sheet_config, dict):
            source_sheet = sheet_config.get("by_year", {}).get(
                vintage, sheet_config.get("by_year", {}).get(str(vintage), sheet_config.get("default"))
            )
        else:
            source_sheet = sheet_config
        if not source_sheet:
            raise ValueError(f"No source sheet configured for {class_name} {vintage}")
        overrides = class_config.get("ay_overrides", {})
        result.append(
            extract_vintage(
                path=path,
                vintage=vintage,
                source_url=url,
                source_hash=sha256(content).hexdigest(),
                source_sheet_name=source_sheet,
                ay_overrides=overrides.get(vintage, overrides.get(str(vintage))),
            )
        )
    return result


def _check(
    vintage: int,
    name: str,
    difference: float,
    tolerance: float,
    detail: str,
    expected: float | None = None,
) -> dict:
    return {
        "vintage": vintage,
        "check": name,
        "difference": float(difference),
        "tolerance": float(tolerance),
        "expected": expected,
        "status": "PASS" if abs(difference) <= tolerance else "FAIL",
        "detail": detail,
    }


def _make_tidy(class_name: str, vintages: list[VintageData]) -> pd.DataFrame:
    premium_by_ay = {
        (vintage.vintage, premium["ay"]): premium["net"]
        for vintage in vintages
        for premium in vintage.premiums
    }
    data = []
    for vintage in vintages:
        for item in vintage.incurred:
            data.append(
                {
                    "cls": class_name,
                    "vintage": item["vintage"],
                    "ay": item["ay"],
                    "eval_year": item["eval_year"],
                    "incurred": item["value"],
                    "nep": (
                        np.nan
                        if item["ay"] == "PRIOR"
                        else premium_by_ay.get((item["vintage"], item["ay"]), np.nan)
                    ),
                }
            )
    return pd.DataFrame(
        data, columns=["cls", "vintage", "ay", "eval_year", "incurred", "nep"]
    )


def _overlap_report(vintages: list[VintageData]) -> pd.DataFrame:
    records = []
    for field in ("incurred", "paid", "ibnr"):
        grouped: dict[tuple[int | str, int], list[dict]] = {}
        for vintage in vintages:
            for item in getattr(vintage, field):
                if item["ay"] == "PRIOR":
                    continue
                grouped.setdefault((item["ay"], item["eval_year"]), []).append(item)
        for (ay, eval_year), items in sorted(grouped.items()):
            if len(items) < 2:
                continue
            items.sort(key=lambda item: item["vintage"])
            first, last = items[0], items[-1]
            difference = last["value"] - first["value"]
            records.append(
                {
                    "measure": field,
                    "ay": ay,
                    "eval_year": eval_year,
                    "first_vintage": first["vintage"],
                    "first_value": first["value"],
                    "latest_vintage": last["vintage"],
                    "latest_value": last["value"],
                    "difference": difference,
                    "status": "RESTATEMENT" if abs(difference) > 2 else "MATCH",
                    "source_files": f"{first['source_file']} -> {last['source_file']}",
                }
            )
    return pd.DataFrame(
        records,
        columns=[
            "measure",
            "ay",
            "eval_year",
            "first_vintage",
            "first_value",
            "latest_vintage",
            "latest_value",
            "difference",
            "status",
            "source_files",
        ],
    )


def _latest_paid_pairs(vintages: list[VintageData]) -> pd.DataFrame:
    incurred = {}
    paid = {}
    for vintage in vintages:
        for item in vintage.incurred:
            if item["ay"] != "PRIOR":
                incurred[(item["vintage"], item["ay"], item["eval_year"])] = item["value"]
        for item in vintage.paid:
            if item["ay"] != "PRIOR":
                paid[(item["vintage"], item["ay"], item["eval_year"])] = item["value"]
    keys = sorted(
        {
            (ay, eval_year)
            for vintage, ay, eval_year in incurred
            if (vintage, ay, eval_year) in paid
        }
    )
    rows = []
    for ay, eval_year in keys:
        vintages_with_both = [
            vintage
            for vintage in range(ay, eval_year + 10)
            if (vintage, ay, eval_year) in incurred and (vintage, ay, eval_year) in paid
        ]
        if not vintages_with_both:
            continue
        vintage = max(vintages_with_both)
        inc = incurred[(vintage, ay, eval_year)]
        paid_value = paid[(vintage, ay, eval_year)]
        if inc == 0:
            continue
        rows.append(
            {
                "ay": ay,
                "eval_year": eval_year,
                "age": eval_year - ay + 1,
                "vintage": vintage,
                "paid": paid_value,
                "incurred": inc,
                "paid_pct_incurred": paid_value / inc,
            }
        )
    return pd.DataFrame(
        rows,
        columns=[
            "ay",
            "eval_year",
            "age",
            "vintage",
            "paid",
            "incurred",
            "paid_pct_incurred",
        ],
    )


def _paid_age_summary(latest_pairs: pd.DataFrame) -> pd.DataFrame:
    grouped = latest_pairs.groupby("age").paid_pct_incurred
    return (
        grouped.agg(
            n="count",
            mean="mean",
            median="median",
            sd="std",
            min="min",
            max="max",
        )
        .reset_index()
    )


def _period_comparison(cy: pd.DataFrame) -> pd.DataFrame:
    definitions = [("2015-2020", 2015, 2020), ("2021-2025", 2021, 2025)]
    rows = []
    for label, start, end in definitions:
        window = cy[cy["vintage"].between(start, end)]
        values = window["pyd_pct_nep"].dropna()
        rows.append(
            {
                "period": label,
                "n": len(values),
                "pyd_sum_000": window["pyd"].sum(),
                "mean_pyd_pct_nep": values.mean(),
                "sd_pyd_pct_nep": values.std(ddof=1),
                "adverse_years": int((values > 0).sum()),
                "adverse_share": (values > 0).mean(),
            }
        )
    return pd.DataFrame(rows)


def _add_fixture_checks(
    class_name: str,
    vintages: list[VintageData],
    cy: pd.DataFrame,
    dev: pd.DataFrame,
    series: pd.DataFrame,
    age: pd.DataFrame,
) -> list[dict]:
    checks = [check.copy() for vintage in vintages for check in vintage.checks]
    if class_name != "OL Occurrence":
        return checks
    for vintage, (expected_pyd, expected_nep) in FIXTURES.items():
        actual = cy.loc[cy["vintage"] == vintage].iloc[0]
        checks.append(
            _check(
                vintage,
                "Fixture PYD",
                actual["pyd"] - expected_pyd,
                5,
                "Published PYD compared with the spec fixture ($000)",
                expected_pyd,
            )
        )
        checks.append(
            _check(
                vintage,
                "Fixture current AY NEP",
                actual["nep_cy"] - expected_nep,
                5,
                "Net earned premium compared with the spec fixture ($000)",
                expected_nep,
            )
        )

    prior = dev[(dev["vintage"] == 2015) & (dev["ay"] == "PRIOR")].iloc[0]["dev"]
    ay2006 = dev[(dev["vintage"] == 2015) & (dev["ay"] == 2006)].iloc[0]["dev"]
    checks.append(_check(2015, "Fixture PRIOR development", prior - 12776, 2, "2015 PRIOR one-year development ($000)", 12776))
    checks.append(_check(2015, "Fixture AY 2006 development", ay2006 - 3820, 2, "2015 AY 2006 one-year development ($000)", 3820))

    row = series.iloc[0]
    checks.extend(
        [
            _check(2025, "Fixture series mean", row["mean"] - 0.037, 0.0015, "Mean of 2015-2025 PYD / NEP", 0.037),
            _check(2025, "Fixture series SD", row["sd"] - 0.047, 0.0015, "Sample standard deviation of PYD / NEP", 0.047),
            _check(2025, "Fixture adverse share", row["adverse_share"] - (9 / 11), 0.01, "Share of calendar years with positive PYD / NEP", 9 / 11),
            _check(2025, "Fixture lag-1 autocorrelation", row["lag1"] - 0.74, 0.02, "Lag-1 autocorrelation of PYD / NEP", 0.74),
        ]
    )
    age2 = age.loc[age["age_now"] == 2].iloc[0]["mean"]
    checks.append(_check(2025, "Fixture age 2 mean", age2 - (-0.014), 0.005, "Age-2 mean development / AY NEP", -0.014))
    return checks


def run_class(class_name: str, class_config: dict, download_missing: bool = True) -> Path:
    print(f"Reading source supplements for {class_name}...")
    vintages = _load_vintages(class_name, class_config, download_missing)
    tidy = _make_tidy(class_name, vintages)
    dev = one_year_dev(tidy)
    cy = cy_summary(dev, tidy).sort_values("vintage").reset_index(drop=True)
    age = dev_by_age(dev).sort_values("age_now").reset_index(drop=True)
    matrix = ay_cy_matrix(dev, class_name).sort_index().sort_index(axis=1)
    stats = series_stats(cy)
    latest_pairs = _latest_paid_pairs(vintages)
    paid_age = _paid_age_summary(latest_pairs)
    overlap = _overlap_report(vintages)
    period = _period_comparison(cy)
    checks = _add_fixture_checks(class_name, vintages, cy, dev, stats, age)
    failures = [check for check in checks if check["status"] != "PASS"]
    if failures:
        details = "; ".join(
            f"{item['vintage']} {item['check']} diff={item['difference']:.4f} tol={item['tolerance']:.4f}"
            for item in failures
        )
        raise RuntimeError(f"Schedule P validation failed; no report was produced: {details}")

    significant_overlaps = overlap[overlap["status"] == "RESTATEMENT"]
    print(f"All {len(checks)} hard validation checks passed.")
    print(
        f"Overlap review: {len(overlap)} comparisons; "
        f"{len(significant_overlaps)} differences exceed $2k."
    )
    output = ROOT / "out" / class_name
    write_outputs(
        out_dir=output,
        class_name=class_name,
        vintages=vintages,
        tidy=tidy,
        dev=dev,
        cy=cy,
        age_summary=age,
        ay_matrix=matrix,
        series=stats,
        paid_age=paid_age,
        latest_pairs=latest_pairs,
        overlap=overlap,
        period_comparison=period,
        parser_checks=checks,
    )
    print(f"Analysis complete: {output.relative_to(ROOT)}")
    return output


def _write_cross_class_comparison(class_names: list[str]) -> None:
    output_root = ROOT / "out"
    records = []
    yearly = []
    for class_name in class_names:
        class_dir = output_root / class_name
        cy = pd.read_csv(class_dir / "pyd_by_calendar_year.csv")
        series = pd.read_csv(class_dir / "series_stats.csv").iloc[0]
        overlaps = pd.read_csv(class_dir / "overlap_differences.csv")
        common = cy[cy["vintage"].between(2018, 2024)]["pyd_pct_nep"].dropna()
        recent_common = cy[cy["vintage"].between(2021, 2024)]["pyd_pct_nep"].dropna()
        record = {
            "class": class_name,
            "full_period_start": int(cy["vintage"].min()),
            "full_period_end": int(cy["vintage"].max()),
            "full_period_n": int(series["n"]),
            "full_period_mean_pyd_pct_nep": series["mean"],
            "full_period_sd_pyd_pct_nep": series["sd"],
            "full_period_adverse_share": series["adverse_share"],
            "full_period_lag1": series["lag1"],
            "common_period_2018_2024_n": len(common),
            "common_period_2018_2024_mean": common.mean(),
            "common_period_2018_2024_sd": common.std(ddof=1),
            "recent_common_period_2021_2024_n": len(recent_common),
            "recent_common_period_2021_2024_mean": recent_common.mean(),
            "recent_common_period_2021_2024_sd": recent_common.std(ddof=1),
            "incurred_overlap_flags": int(
                ((overlaps["measure"] == "incurred") & (overlaps["status"] == "RESTATEMENT")).sum()
            ),
            "paid_overlap_flags": int(
                ((overlaps["measure"] == "paid") & (overlaps["status"] == "RESTATEMENT")).sum()
            ),
            "ibnr_overlap_flags": int(
                ((overlaps["measure"] == "ibnr") & (overlaps["status"] == "RESTATEMENT")).sum()
            ),
        }
        records.append(record)
        yearly.append(cy[["vintage", "pyd_pct_nep"]].assign(cls=class_name))

    comparison = pd.DataFrame(records)
    comparison.to_csv(output_root / "class_comparison.csv", index=False)
    annual = pd.concat(yearly, ignore_index=True)
    plt.figure(figsize=(11, 6))
    for class_name in class_names:
        group = annual[annual["cls"] == class_name]
        plt.plot(
            group["vintage"],
            group["pyd_pct_nep"] * 100,
            marker="o",
            linewidth=1.8,
            label=class_name,
        )
    plt.axhline(0, color="black", linewidth=0.8)
    plt.title("Calendar-Year PYD / Current AY Net Earned Premium by Class\nNet, accident-year basis")
    plt.xlabel("Calendar year")
    plt.ylabel("PYD / NEP (%)")
    plt.xticks(sorted(annual["vintage"].unique()), rotation=45)
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_root / "class_comparison.png", dpi=180)
    plt.close()
    print(f"Cross-class comparison: {(output_root / 'class_comparison.csv').relative_to(ROOT)}")


def _selected_classes(config: dict, class_name: str | None, all_classes: bool) -> list[str]:
    available = config["classes"]
    if all_classes:
        return list(available)
    if class_name is None:
        if len(available) == 1:
            return list(available)
        raise ValueError("Choose --class or --all")
    if class_name not in available:
        raise ValueError(f"Class {class_name!r} is not configured. Available: {', '.join(available)}")
    return [class_name]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m schedp")
    subparsers = parser.add_subparsers(dest="command", required=True)
    for command in ("run", "fetch"):
        command_parser = subparsers.add_parser(command)
        command_parser.add_argument("--class", dest="class_name")
        command_parser.add_argument("--all", action="store_true")
    args = parser.parse_args(argv)
    config = _read_config()
    try:
        names = _selected_classes(config, args.class_name, args.all)
        for name in names:
            class_config = config["classes"][name]
            if args.command == "fetch":
                _load_vintages(name, class_config, download_missing=True)
            else:
                run_class(name, class_config, download_missing=True)
        if args.command == "run" and args.all:
            _write_cross_class_comparison(names)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return 0
