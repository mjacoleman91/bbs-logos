from schedp.runner import main

raise SystemExit(main())
