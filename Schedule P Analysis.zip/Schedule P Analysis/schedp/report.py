from __future__ import annotations

from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from openpyxl import Workbook, load_workbook
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.formatting.rule import ColorScaleRule
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.table import Table, TableStyleInfo


NAVY = "17365D"
BLUE = "1F4E78"
LIGHT_BLUE = "D9EAF7"
GREEN = "E2F0D9"
RED = "FCE4D6"


def _write_csv(frame: pd.DataFrame, path: Path) -> None:
    frame.to_csv(path, index=False, na_rep="")


def _style_sheet(ws, header_row: int = 1) -> None:
    ws.freeze_panes = f"A{header_row + 1}"
    ws.sheet_view.showGridLines = False
    for cell in ws[header_row]:
        if cell.value is not None:
            cell.fill = PatternFill("solid", fgColor=NAVY)
            cell.font = Font(color="FFFFFF", bold=True)
            cell.alignment = Alignment(vertical="center", wrap_text=True)
    ws.row_dimensions[header_row].height = 30
    for col in ws.columns:
        letter = col[0].column_letter
        values = [str(cell.value) for cell in col[:200] if cell.value is not None]
        width = min(max((len(value) for value in values), default=8) + 2, 48)
        ws.column_dimensions[letter].width = max(width, 12)


def _add_table(ws, name: str) -> None:
    if ws.max_row < 2 or ws.max_column < 1:
        return
    table = Table(displayName=name, ref=f"A1:{ws.cell(ws.max_row, ws.max_column).coordinate}")
    table.tableStyleInfo = TableStyleInfo(
        name="TableStyleMedium2",
        showFirstColumn=False,
        showLastColumn=False,
        showRowStripes=True,
        showColumnStripes=False,
    )
    ws.add_table(table)


def _sumifs(
    sum_sheet: str,
    sum_col: str,
    criteria: list[tuple[str, str]],
    first_row: int,
    last_row: int,
) -> str:
    args = [f"'{sum_sheet}'!${sum_col}${first_row}:${sum_col}${last_row}"]
    for col, criterion in criteria:
        args.extend(
            [
                f"'{sum_sheet}'!${col}${first_row}:${col}${last_row}",
                _criteria_arg(criterion),
            ]
        )
    return f"SUMIFS({','.join(args)})"


def _countifs(
    sheet: str,
    criteria: list[tuple[str, str]],
    first_row: int,
    last_row: int,
) -> str:
    args = []
    for col, criterion in criteria:
        args.extend(
            [f"'{sheet}'!${col}${first_row}:${col}${last_row}", _criteria_arg(criterion)]
        )
    return f"COUNTIFS({','.join(args)})"


def _criteria_arg(criterion: str) -> str:
    if criterion == "<>" or criterion.startswith("<>") and not criterion.startswith('"'):
        return f'"{criterion}"'
    return criterion


def _write_frame_sheet(wb: Workbook, name: str, frame: pd.DataFrame, table_name: str):
    ws = wb.create_sheet(name)
    ws.append(list(frame.columns))
    for row in frame.itertuples(index=False, name=None):
        ws.append([None if pd.isna(value) else value for value in row])
    _style_sheet(ws)
    _add_table(ws, table_name)
    return ws


def _formula_workbook(
    path: Path,
    class_name: str,
    vintages: list[Any],
    input_rows: dict[str, list[dict[str, Any]]],
    source_rows: list[dict[str, Any]],
    parser_checks: list[dict[str, Any]],
    latest_pairs: pd.DataFrame,
    overlap: pd.DataFrame,
    period_comparison: pd.DataFrame,
) -> None:
    wb = Workbook()
    readme = wb.active
    readme.title = "Read Me"
    readme.sheet_view.showGridLines = False
    readme["A1"] = f"Schedule P Reserve Development — {class_name}"
    readme["A1"].font = Font(size=18, bold=True, color="FFFFFF")
    readme["A1"].fill = PatternFill("solid", fgColor=NAVY)
    readme.merge_cells("A1:F1")
    instructions = [
        ("Purpose", "Traceable analysis of W. R. Berkley Schedule P Part 2 incurred development, with Part 3 paid-pattern context."),
        ("Units and basis", "Amounts are $000; net of reinsurance; accident-year basis; booked estimates including IBNR."),
        ("Sign convention", "Positive development is adverse (reserve increase); negative development is favourable (reserve release)."),
        ("Formula flow", "Source-extracted values feed Developments, CY Summary, Age Summary, AY × CY, and paid-to-incurred formulas."),
        ("Recalculation", "Formula cells are preserved and set to recalculate when opened in a spreadsheet application. This computer has no Excel/LibreOffice calculation engine."),
        ("Interpretation", "Schedule P reflects reserving practice as well as loss emergence; immature accident years can be booked at a priori loss ratios."),
        ("Restatements", "Overlapping AY/evaluation-year values are compared across vintages. Differences are shown in Overlaps; no value is silently overwritten."),
        ("Supplementary analysis", "Paid-to-incurred ratios and early/recent period comparisons are descriptive; they are not pure settlement or stochastic estimates."),
        ("Source selection", "The aggregate Filed Total sheet was used for the Other Liability Occurrence supplement. Source sheet coordinates are recorded beside extracted values."),
        ("2015 source format", "The official 2015 URL ends in .xls, but the downloaded payload is an XLSX ZIP workbook; the parser detects the actual file format."),
    ]
    for row, (label, text) in enumerate(instructions, start=3):
        readme.cell(row, 1, label).font = Font(bold=True, color=BLUE)
        readme.cell(row, 2, text).alignment = Alignment(wrap_text=True, vertical="top")
        readme.merge_cells(start_row=row, start_column=2, end_row=row, end_column=6)
        readme.row_dimensions[row].height = 34
    readme.column_dimensions["A"].width = 26
    for col in "BCDEF":
        readme.column_dimensions[col].width = 22

    raw_incurred = _write_frame_sheet(
        wb,
        "Raw Incurred",
        pd.DataFrame(
            input_rows["incurred"],
            columns=["Vintage", "AY", "Eval Year", "Incurred ($000)", "Source File", "Sheet", "Cell"],
        ),
        "RawIncurred",
    )
    raw_paid = _write_frame_sheet(
        wb,
        "Raw Paid",
        pd.DataFrame(
            input_rows["paid"],
            columns=["Vintage", "AY", "Eval Year", "Paid ($000)", "Source File", "Sheet", "Cell"],
        ),
        "RawPaid",
    )
    raw_ibnr = _write_frame_sheet(
        wb,
        "Raw IBNR",
        pd.DataFrame(
            input_rows["ibnr"],
            columns=["Vintage", "AY", "Eval Year", "Bulk & IBNR ($000)", "Source File", "Sheet", "Cell"],
        ),
        "RawIBNR",
    )
    premiums = _write_frame_sheet(
        wb,
        "Premiums",
        pd.DataFrame(
            input_rows["premiums"],
            columns=[
                "Vintage",
                "AY",
                "Direct & Assumed ($000)",
                "Ceded ($000)",
                "Net EP ($000)",
                "Source File",
                "Sheet",
                "Direct Cell",
                "Ceded Cell",
                "Net Cell",
            ],
        ),
        "Premiums",
    )
    published = _write_frame_sheet(
        wb,
        "Published Dev",
        pd.DataFrame(
            input_rows["published"],
            columns=[
                "Vintage",
                "AY",
                "Published One Year ($000)",
                "Published Two Year ($000)",
                "Source File",
                "Sheet",
                "One Year Cell",
                "Two Year Cell",
            ],
        ),
        "PublishedDev",
    )

    raw_incurred_last = raw_incurred.max_row
    raw_paid_last = raw_paid.max_row
    raw_ibnr_last = raw_ibnr.max_row
    premiums_last = premiums.max_row
    published_last = published.max_row

    development = wb.create_sheet("Developments")
    development.append(
        [
            "Vintage",
            "AY",
            "Age at Current Eval",
            "Incurred Now ($000)",
            "Incurred Prior ($000)",
            "One Year Dev ($000)",
            "AY Net EP ($000)",
            "Dev / AY NEP",
            "Published One Year ($000)",
            "One Year Difference ($000)",
            "Incurred Two Years Prior ($000)",
            "Calculated Two Year ($000)",
            "Published Two Year ($000)",
            "Two Year Difference ($000)",
            "Abs One Year Difference",
            "Abs Two Year Difference",
        ]
    )
    published_keys = [
        (item["Vintage"], item["AY"])
        for item in input_rows["published"]
        if item["AY"] != "TOTALS"
    ]
    for vintage, ay in published_keys:
        row = development.max_row + 1
        development.append(
            [
                vintage,
                ay,
                None if ay == "PRIOR" else f"=A{row}-B{row}+1",
                f"={_sumifs('Raw Incurred','D',[('A',f'A{row}'),('B',f'B{row}'),('C',f'A{row}')],2,raw_incurred_last)}",
                f'=IF({_countifs("Raw Incurred",[("A",f"A{row}"),("B",f"B{row}"),("C",f"A{row}-1")],2,raw_incurred_last)}=0,"",{_sumifs("Raw Incurred","D",[("A",f"A{row}"),("B",f"B{row}"),("C",f"A{row}-1")],2,raw_incurred_last)})',
                f'=IF(E{row}="","",D{row}-E{row})',
                "" if ay == "PRIOR" else f"={_sumifs('Premiums','E',[('A',f'A{row}'),('B',f'B{row}')],2,premiums_last)}",
                f'=IFERROR(F{row}/G{row},"")',
                f'=IF({_countifs("Published Dev",[("A",f"A{row}"),("B",f"B{row}"),("C","<>")],2,published_last)}=0,"",{_sumifs("Published Dev","C",[("A",f"A{row}"),("B",f"B{row}")],2,published_last)})',
                f'=IF(I{row}="","",F{row}-I{row})',
                f'=IF({_countifs("Raw Incurred",[("A",f"A{row}"),("B",f"B{row}"),("C",f"A{row}-2")],2,raw_incurred_last)}=0,"",{_sumifs("Raw Incurred","D",[("A",f"A{row}"),("B",f"B{row}"),("C",f"A{row}-2")],2,raw_incurred_last)})',
                f'=IF(K{row}="","",D{row}-K{row})',
                f'=IF({_countifs("Published Dev",[("A",f"A{row}"),("B",f"B{row}"),("D","<>")],2,published_last)}=0,"",{_sumifs("Published Dev","D",[("A",f"A{row}"),("B",f"B{row}")],2,published_last)})',
                f'=IF(M{row}="","",L{row}-M{row})',
                f'=IF(J{row}="","",ABS(J{row}))',
                f'=IF(N{row}="","",ABS(N{row}))',
            ]
        )
    _style_sheet(development)
    _add_table(development, "Developments")
    for row in range(2, development.max_row + 1):
        development.cell(row, 8).number_format = "0.0%"

    cy = wb.create_sheet("CY Summary")
    cy.append(
        [
            "Calendar Year",
            "PYD ($000)",
            "Current AY Net EP ($000)",
            "PYD / Current AY NEP",
            "PRIOR Row PYD ($000)",
            "Published PYD ($000)",
            "PYD Difference ($000)",
        ]
    )
    for vintage in sorted({item["Vintage"] for item in input_rows["published"]}):
        row = cy.max_row + 1
        cy.append(
            [
                vintage,
                f"={_sumifs('Developments','F',[('A',f'A{row}')],2,development.max_row)}",
                f"={_sumifs('Premiums','E',[('A',f'A{row}'),('B',f'A{row}')],2,premiums_last)}",
                f'=IFERROR(B{row}/C{row},"")',
                f"={_sumifs('Developments','F',[('A',f'A{row}'),('B','\"PRIOR\"')],2,development.max_row)}",
                f"={_sumifs('Published Dev','C',[('A',f'A{row}'),('B','\"TOTALS\"')],2,published_last)}",
                f"=B{row}-F{row}",
            ]
        )
    _style_sheet(cy)
    _add_table(cy, "CYSummary")
    for row in range(2, cy.max_row + 1):
        cy.cell(row, 4).number_format = "0.0%"

    series = wb.create_sheet("Series Stats")
    series.append(["Class", "N", "Mean PYD / NEP", "SD", "Adverse Share", "Lag-1 Autocorrelation"])
    series.append(
        [
            class_name,
            f"=COUNT('CY Summary'!$D$2:$D${cy.max_row})",
            f"=AVERAGE('CY Summary'!$D$2:$D${cy.max_row})",
            f"=STDEV.S('CY Summary'!$D$2:$D${cy.max_row})",
            f'=COUNTIF(\'CY Summary\'!$D$2:$D${cy.max_row},">0")/B2',
            f"=CORREL('CY Summary'!$D$2:$D${cy.max_row - 1},'CY Summary'!$D$3:$D${cy.max_row})",
        ]
    )
    _style_sheet(series)
    _add_table(series, "SeriesStatistics")
    for column in range(3, 7):
        series.cell(2, column).number_format = "0.0%"

    period = wb.create_sheet("Period Comparison")
    period.append(
        [
            "Period",
            "Start Year",
            "End Year",
            "N",
            "Total PYD ($000)",
            "Mean PYD / NEP",
            "SD",
            "Adverse Share",
            "Caveat",
        ]
    )
    for label, start, end in (("2015-2020", 2015, 2020), ("2021-2025", 2021, 2025)):
        row = period.max_row + 1
        year_range = f"'CY Summary'!$A$2:$A${cy.max_row}"
        pyd_range = f"'CY Summary'!$B$2:$B${cy.max_row}"
        pct_range = f"'CY Summary'!$D$2:$D${cy.max_row}"
        period.append(
            [
                label,
                start,
                end,
                f"=COUNTIFS({year_range},\">=\"&B{row},{year_range},\"<=\"&C{row})",
                f"=SUMIFS({pyd_range},{year_range},\">=\"&B{row},{year_range},\"<=\"&C{row})",
                f"=AVERAGEIFS({pct_range},{year_range},\">=\"&B{row},{year_range},\"<=\"&C{row})",
                f'=IFERROR(STDEV.S(FILTER({pct_range},({year_range}>=B{row})*({year_range}<=C{row}))),"")',
                f'=IFERROR(COUNTIFS({year_range},\">=\"&B{row},{year_range},\"<=\"&C{row},{pct_range},\">0\")/D{row},"")',
                "Descriptive comparison only; short, overlapping experience is not a credibility-adjusted forecast.",
            ]
        )
    _style_sheet(period)
    _add_table(period, "PeriodComparison")
    for row in range(2, period.max_row + 1):
        for column in range(6, 9):
            period.cell(row, column).number_format = "0.0%"
    pyd_chart = BarChart()
    pyd_chart.type = "col"
    pyd_chart.style = 10
    pyd_chart.title = "PYD as % of Current AY NEP"
    pyd_chart.y_axis.title = "PYD / NEP"
    pyd_chart.x_axis.title = "Calendar year"
    pyd_chart.add_data(Reference(cy, min_col=4, min_row=1, max_row=cy.max_row), titles_from_data=True)
    pyd_chart.set_categories(Reference(cy, min_col=1, min_row=2, max_row=cy.max_row))
    pyd_chart.height = 8
    pyd_chart.width = 16
    cy.add_chart(pyd_chart, "I2")

    age = wb.create_sheet("Age Summary")
    age.append(["Age at Current Eval", "N", "Mean", "Median", "SD", "Min", "Max"])
    for target_age in range(2, 11):
        row = age.max_row + 1
        ratio = f"'Developments'!$H$2:$H${development.max_row}"
        age_range = f"'Developments'!$C$2:$C${development.max_row}"
        age.append(
            [
                target_age,
                f'=COUNTIFS({age_range},A{row},{ratio},">=0")+COUNTIFS({age_range},A{row},{ratio},"<0")',
                f'=IFERROR(AVERAGEIF({age_range},A{row},{ratio}),"")',
                f'=IFERROR(MEDIAN(FILTER({ratio},{age_range}=A{row})),"")',
                f'=IFERROR(STDEV.S(FILTER({ratio},{age_range}=A{row})),"")',
                f'=IFERROR(MINIFS({ratio},{age_range},A{row}),"")',
                f'=IFERROR(MAXIFS({ratio},{age_range},A{row}),"")',
            ]
        )
    _style_sheet(age)
    _add_table(age, "AgeSummary")
    for row in range(2, age.max_row + 1):
        for col in range(3, 8):
            age.cell(row, col).number_format = "0.0%"

    matrix = wb.create_sheet("AY x CY")
    matrix.append(["Accident Year"] + sorted({item["Vintage"] for item in input_rows["published"]}))
    for ay in sorted(
        {item["AY"] for item in input_rows["published"] if isinstance(item["AY"], int)}
    ):
        row = matrix.max_row + 1
        matrix.cell(row, 1, ay)
        for col in range(2, matrix.max_column + 1):
            vintage_cell = f"{_column_letter(col)}$1"
            ratio = f"'Developments'!$H$2:$H${development.max_row}"
            vintage_rng = f"'Developments'!$A$2:$A${development.max_row}"
            ay_rng = f"'Developments'!$B$2:$B${development.max_row}"
            matrix.cell(
                row,
                col,
                f'=IF(COUNTIFS({vintage_rng},{vintage_cell},{ay_rng},$A{row},{ratio},">=0")+COUNTIFS({vintage_rng},{vintage_cell},{ay_rng},$A{row},{ratio},"<0")=0,"",SUMIFS({ratio},{vintage_rng},{vintage_cell},{ay_rng},$A{row}))',
            )
            matrix.cell(row, col).number_format = "0.0%"
    _style_sheet(matrix)
    matrix.conditional_formatting.add(
        f"B2:{_column_letter(matrix.max_column)}{matrix.max_row}",
        ColorScaleRule(
            start_type="min",
            start_color="63BE7B",
            mid_type="percentile",
            mid_value=50,
            mid_color="FFEB84",
            end_type="max",
            end_color="F8696B",
        ),
    )

    paid_ratio = wb.create_sheet("Paid Pattern")
    paid_ratio.append(
        [
            "AY",
            "Eval Year",
            "Age",
            "Latest Source Vintage",
            "Cumulative Paid ($000)",
            "Incurred ($000)",
            "Paid / Incurred",
        ]
    )
    for item in latest_pairs.to_dict("records"):
        row = paid_ratio.max_row + 1
        paid_ratio.append(
            [
                item["ay"],
                item["eval_year"],
                item["age"],
                item["vintage"],
                f"={_sumifs('Raw Paid','D',[('A',f'D{row}'),('B',f'A{row}'),('C',f'B{row}')],2,raw_paid_last)}",
                f"={_sumifs('Raw Incurred','D',[('A',f'D{row}'),('B',f'A{row}'),('C',f'B{row}')],2,raw_incurred_last)}",
                f'=IFERROR(E{row}/F{row},"")',
            ]
        )
    _style_sheet(paid_ratio)
    _add_table(paid_ratio, "PaidPattern")
    for row in range(2, paid_ratio.max_row + 1):
        paid_ratio.cell(row, 7).number_format = "0.0%"

    paid_summary = wb.create_sheet("Paid by Age")
    paid_summary.append(["Age", "N", "Mean Paid / Incurred", "Median", "SD", "Min", "Max"])
    for target_age in range(1, 11):
        row = paid_summary.max_row + 1
        age_rng = f"'Paid Pattern'!$C$2:$C${paid_ratio.max_row}"
        ratio_rng = f"'Paid Pattern'!$G$2:$G${paid_ratio.max_row}"
        paid_summary.append(
            [
                target_age,
                f'=COUNTIFS({age_rng},A{row},{ratio_rng},">=0")+COUNTIFS({age_rng},A{row},{ratio_rng},"<0")',
                f'=IFERROR(AVERAGEIF({age_rng},A{row},{ratio_rng}),"")',
                f'=IFERROR(MEDIAN(FILTER({ratio_rng},{age_rng}=A{row})),"")',
                f'=IFERROR(STDEV.S(FILTER({ratio_rng},{age_rng}=A{row})),"")',
                f'=IFERROR(MINIFS({ratio_rng},{age_rng},A{row}),"")',
                f'=IFERROR(MAXIFS({ratio_rng},{age_rng},A{row}),"")',
            ]
        )
    _style_sheet(paid_summary)
    _add_table(paid_summary, "PaidByAge")
    for row in range(2, paid_summary.max_row + 1):
        for col in range(3, 8):
            paid_summary.cell(row, col).number_format = "0.0%"
    paid_chart = LineChart()
    paid_chart.title = "Cumulative Paid / Incurred by Age"
    paid_chart.y_axis.title = "Paid / Incurred"
    paid_chart.x_axis.title = "Accident-year age"
    paid_chart.add_data(
        Reference(paid_summary, min_col=3, min_row=1, max_row=paid_summary.max_row),
        titles_from_data=True,
    )
    paid_chart.set_categories(Reference(paid_summary, min_col=1, min_row=2, max_row=paid_summary.max_row))
    paid_chart.height = 8
    paid_chart.width = 15
    paid_summary.add_chart(paid_chart, "I2")

    sources = wb.create_sheet("Sources")
    sources.append(["Vintage", "Local File", "Official URL", "SHA-256", "Source Sheet", "Notes"])
    for item in source_rows:
        sources.append(
            [
                item["vintage"],
                item["source_file"],
                item["source_url"],
                item["source_hash"],
                item["source_sheet"],
                item.get("notes", ""),
            ]
        )
    _style_sheet(sources)
    _add_table(sources, "SourceManifest")

    overlaps_sheet = wb.create_sheet("Overlaps")
    overlap_columns = list(overlap.columns)
    overlaps_sheet.append(overlap_columns)
    for record in overlap.itertuples(index=False, name=None):
        overlaps_sheet.append([None if pd.isna(value) else value for value in record])
    _style_sheet(overlaps_sheet)
    _add_table(overlaps_sheet, "OverlapChecks")

    checks = wb.create_sheet("Checks")
    checks.append(["Vintage", "Check", "Difference", "Tolerance", "Status", "Expected", "Details"])
    for item in parser_checks:
        row = checks.max_row + 1
        check_name = item["check"]
        if check_name.startswith("Net premium AY "):
            ay = int(check_name.rsplit(" ", 1)[1])
            premium_row = next(
                r
                for r in range(2, premiums.max_row + 1)
                if premiums.cell(r, 1).value == item["vintage"]
                and premiums.cell(r, 2).value == ay
            )
            formula = f"=Premiums!C{premium_row}-Premiums!D{premium_row}-Premiums!E{premium_row}"
        elif check_name == "Part 2 published One Year rows":
            formula = f'=MAXIFS(Developments!$O$2:$O${development.max_row},Developments!$A$2:$A${development.max_row},A{row})'
        elif check_name == "Part 2 published One Year total":
            formula = (
                f"={_sumifs('Published Dev','C',[('A',f'A{row}') ,('B','\"TOTALS\"')],2,published_last)}"
                f"-{_sumifs('Published Dev','C',[('A',f'A{row}'),('B','<>TOTALS')],2,published_last)}"
            )
        elif check_name == "Part 2 recomputed One Year total":
            formula = (
                f"={_sumifs('Developments','F',[('A',f'A{row}')],2,development.max_row)}"
                f"-{_sumifs('Published Dev','C',[('A',f'A{row}'),('B','\"TOTALS\"')],2,published_last)}"
            )
        elif check_name == "Part 2 published Two Year rows":
            formula = f'=MAXIFS(Developments!$P$2:$P${development.max_row},Developments!$A$2:$A${development.max_row},A{row})'
        elif check_name == "Fixture PYD":
            formula = f"=SUMIFS('CY Summary'!$B$2:$B${cy.max_row},'CY Summary'!$A$2:$A${cy.max_row},A{row})-{item['expected']}"
        elif check_name == "Fixture current AY NEP":
            formula = f"={_sumifs('Premiums','E',[('A',f'A{row}'),('B',f'A{row}')],2,premiums_last)}-{item['expected']}"
        elif check_name == "Fixture PRIOR development":
            formula = f"={_sumifs('Developments','F',[('A',f'A{row}'),('B','\"PRIOR\"')],2,development.max_row)}-{item['expected']}"
        elif check_name == "Fixture AY 2006 development":
            formula = f"={_sumifs('Developments','F',[('A',f'A{row}'),('B','2006')],2,development.max_row)}-{item['expected']}"
        elif check_name == "Fixture series mean":
            formula = f"='Series Stats'!C2-{item['expected']}"
        elif check_name == "Fixture series SD":
            formula = f"='Series Stats'!D2-{item['expected']}"
        elif check_name == "Fixture adverse share":
            formula = f"='Series Stats'!E2-{item['expected']}"
        elif check_name == "Fixture lag-1 autocorrelation":
            formula = f"='Series Stats'!F2-{item['expected']}"
        elif check_name == "Fixture age 2 mean":
            formula = f"='Age Summary'!C2-{item['expected']}"
        else:
            formula = f"={item['difference']}"
        checks.append(
            [
                item["vintage"],
                check_name,
                formula,
                item["tolerance"],
                f'=IF(ABS(C{row})<=D{row},"PASS","FAIL")',
                item.get("expected"),
                item["detail"],
            ]
        )
    _style_sheet(checks)
    _add_table(checks, "ReconciliationChecks")
    for row in range(2, checks.max_row + 1):
        checks.cell(row, 5).fill = PatternFill("solid", fgColor=GREEN)

    for sheet in wb.worksheets:
        sheet.sheet_view.showGridLines = False
    wb.calculation.fullCalcOnLoad = True
    wb.calculation.forceFullCalc = True
    wb.calculation.calcMode = "auto"
    wb.save(path)


def _column_letter(col: int) -> str:
    result = ""
    while col:
        col, remainder = divmod(col - 1, 26)
        result = chr(65 + remainder) + result
    return result


def write_outputs(
    out_dir: Path,
    class_name: str,
    vintages: list[Any],
    tidy: pd.DataFrame,
    dev: pd.DataFrame,
    cy: pd.DataFrame,
    age_summary: pd.DataFrame,
    ay_matrix: pd.DataFrame,
    series: pd.DataFrame,
    paid_age: pd.DataFrame,
    latest_pairs: pd.DataFrame,
    overlap: pd.DataFrame,
    period_comparison: pd.DataFrame,
    parser_checks: list[dict[str, Any]],
) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    _write_csv(tidy, out_dir / "tidy.csv")
    _write_csv(cy, out_dir / "pyd_by_calendar_year.csv")
    _write_csv(dev, out_dir / "one_year_development.csv")
    _write_csv(age_summary, out_dir / "dev_by_age.csv")
    _write_csv(ay_matrix.rename_axis("ay").reset_index(), out_dir / "ay_by_cy_matrix.csv")
    _write_csv(series, out_dir / "series_stats.csv")
    _write_csv(paid_age, out_dir / "paid_to_incurred_by_age.csv")
    _write_csv(latest_pairs, out_dir / "paid_to_incurred_cells.csv")
    _write_csv(overlap, out_dir / "overlap_differences.csv")
    _write_csv(period_comparison, out_dir / "period_comparison.csv")
    _write_csv(pd.DataFrame(parser_checks), out_dir / "reconciliation_checks.csv")

    plt.figure(figsize=(10, 5.5))
    plt.bar(cy["vintage"], cy["pyd_pct_nep"] * 100, color="#4472C4")
    plt.axhline(0, color="black", linewidth=0.8)
    plt.title(f"{class_name}: PYD / Current AY Net Earned Premium\nNet, accident-year basis, $000")
    plt.xlabel("Calendar year")
    plt.ylabel("PYD / NEP (%)")
    plt.xticks(cy["vintage"], rotation=45)
    plt.tight_layout()
    plt.savefig(out_dir / "pyd_pct_nep.png", dpi=180)
    plt.close()

    plt.figure(figsize=(11, 6))
    values = ay_matrix.to_numpy(dtype=float)
    image = plt.imshow(values, aspect="auto", interpolation="nearest", cmap="RdYlGn_r")
    plt.colorbar(image, label="Development / AY NEP")
    plt.title(f"{class_name}: AY x Calendar-Year One-Year Development\nNet, accident-year basis, $000")
    plt.xlabel("Calendar year")
    plt.ylabel("Accident year")
    plt.xticks(np.arange(len(ay_matrix.columns)), ay_matrix.columns, rotation=45)
    plt.yticks(np.arange(len(ay_matrix.index)), ay_matrix.index)
    plt.tight_layout()
    plt.savefig(out_dir / "ay_cy_heatmap.png", dpi=180)
    plt.close()

    plt.figure(figsize=(9, 5.5))
    plt.plot(paid_age["age"], paid_age["mean"] * 100, marker="o", color="#70AD47")
    plt.fill_between(
        paid_age["age"],
        (paid_age["mean"] - paid_age["sd"]).to_numpy() * 100,
        (paid_age["mean"] + paid_age["sd"]).to_numpy() * 100,
        alpha=0.2,
        color="#70AD47",
    )
    plt.title(f"{class_name}: Cumulative Paid / Incurred by AY Age\nNet, accident-year basis")
    plt.xlabel("Accident-year age")
    plt.ylabel("Paid / Incurred (%)")
    plt.xticks(paid_age["age"])
    plt.ylim(bottom=0)
    plt.tight_layout()
    plt.savefig(out_dir / "paid_to_incurred_by_age.png", dpi=180)
    plt.close()

    input_rows = {
        "incurred": [
            {
                "Vintage": item["vintage"],
                "AY": item["ay"],
                "Eval Year": item["eval_year"],
                "Incurred ($000)": item["value"],
                "Source File": item["source_file"],
                "Sheet": item["source_sheet"],
                "Cell": item["source_cell"],
            }
            for vintage in vintages
            for item in vintage.incurred
        ],
        "paid": [
            {
                "Vintage": item["vintage"],
                "AY": item["ay"],
                "Eval Year": item["eval_year"],
                "Paid ($000)": item["value"],
                "Source File": item["source_file"],
                "Sheet": item["source_sheet"],
                "Cell": item["source_cell"],
            }
            for vintage in vintages
            for item in vintage.paid
        ],
        "ibnr": [
            {
                "Vintage": item["vintage"],
                "AY": item["ay"],
                "Eval Year": item["eval_year"],
                "Bulk & IBNR ($000)": item["value"],
                "Source File": item["source_file"],
                "Sheet": item["source_sheet"],
                "Cell": item["source_cell"],
            }
            for vintage in vintages
            for item in vintage.ibnr
        ],
        "premiums": [
            {
                "Vintage": item["vintage"],
                "AY": item["ay"],
                "Direct & Assumed ($000)": item["direct"],
                "Ceded ($000)": item["ceded"],
                "Net EP ($000)": item["net"],
                "Source File": item["source_file"],
                "Sheet": item["source_sheet"],
                "Direct Cell": item["direct_cell"],
                "Ceded Cell": item["ceded_cell"],
                "Net Cell": item["net_cell"],
            }
            for vintage in vintages
            for item in vintage.premiums
        ],
        "published": [
            {
                "Vintage": item["vintage"],
                "AY": item["ay"],
                "Published One Year ($000)": item["one_year"],
                "Published Two Year ($000)": item["two_year"],
                "Source File": item["source_file"],
                "Sheet": item["source_sheet"],
                "One Year Cell": item["one_year_cell"],
                "Two Year Cell": item["two_year_cell"],
            }
            for vintage in vintages
            for item in vintage.published_dev
        ],
    }
    source_rows = [
        {
            "vintage": item.vintage,
            "source_file": item.source_file,
            "source_url": item.source_url,
            "source_hash": item.source_hash,
            "source_sheet": item.source_sheet,
            "notes": (
                "2015 URL extension is .xls; payload is XLSX"
                if item.vintage == 2015 and class_name == "OL Occurrence"
                else (
                    "Source AY labels at A70, A87, A103 corrected from 2017 to 2018; source file unchanged."
                    if item.vintage == 2019
                    and class_name == "Reinsurance Non-Proportional Assumed Liability"
                    else ""
                )
            ),
        }
        for item in vintages
    ]
    _write_csv(pd.DataFrame(source_rows), out_dir / "source_manifest.csv")
    _formula_workbook(
        out_dir / "summary.xlsx",
        class_name,
        vintages,
        input_rows,
        source_rows,
        parser_checks,
        latest_pairs,
        overlap,
        period_comparison,
    )
