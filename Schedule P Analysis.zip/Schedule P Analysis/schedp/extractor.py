from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
import re
from typing import Any

import xlrd
from openpyxl import load_workbook


INCURRED_TITLE = "INCURRED NET LOSSES AND DEFENSE AND COST CONTAINMENT EXPENSES REPORTED AT YEAR END"
PAID_TITLE = "CUMULATIVE PAID NET LOSSES AND DEFENSE AND COST CONTAINMENT EXPENSES REPORTED AT YEAR END"
IBNR_TITLE = "BULK AND IBNR RESERVES ON NET LOSSES AND DEFENSE AND COST CONTAINMENT EXPENSES REPORTED AT YEAR END"
YEAR_RE = re.compile(r"^(?:19|20)\d{2}$")


@dataclass
class VintageData:
    vintage: int
    source_file: str
    source_url: str
    source_hash: str
    source_sheet: str
    incurred: list[dict[str, Any]]
    paid: list[dict[str, Any]]
    ibnr: list[dict[str, Any]]
    premiums: list[dict[str, Any]]
    published_dev: list[dict[str, Any]]
    checks: list[dict[str, Any]]


def _year(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)) and int(value) == value and 1900 <= int(value) <= 2100:
        return int(value)
    if isinstance(value, str) and YEAR_RE.fullmatch(value.strip()):
        return int(value.strip())
    return None


def _number(value: Any) -> float | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    return None


def _label(value: Any) -> str:
    return value.strip().upper() if isinstance(value, str) else ""


def _column_name(index: int) -> str:
    out = ""
    while index:
        index, rem = divmod(index - 1, 26)
        out = chr(65 + rem) + out
    return out


def _load_sheets(path: Path) -> dict[str, list[list[Any]]]:
    content = path.read_bytes()
    if content.startswith(b"PK"):
        workbook = load_workbook(BytesIO(content), read_only=True, data_only=True)
        try:
            return {
                sheet.title: [list(row) for row in sheet.iter_rows(values_only=True)]
                for sheet in workbook.worksheets
            }
        finally:
            workbook.close()
    workbook = xlrd.open_workbook(file_contents=content, on_demand=True)
    try:
        return {
            sheet.name: [
                [sheet.cell_value(row, col) for col in range(sheet.ncols)]
                for row in range(sheet.nrows)
            ]
            for sheet in workbook.sheets()
        }
    finally:
        workbook.release_resources()


def _get(rows: list[list[Any]], row: int, col: int) -> Any:
    if row < 1 or col < 1 or row > len(rows) or col > len(rows[row - 1]):
        return None
    return rows[row - 1][col - 1]


def _cell(row: int, col: int) -> str:
    return f"{_column_name(col)}{row}"


def _find_label(rows: list[list[Any]], contains: str) -> tuple[int, int] | None:
    needle = contains.upper()
    for row_index, row in enumerate(rows, start=1):
        for col_index, value in enumerate(row, start=1):
            if isinstance(value, str) and needle in value.upper():
                return row_index, col_index
    return None


def _numeric_or_year_label(value: Any) -> int | str | None:
    year = _year(value)
    if year is not None:
        return year
    if _label(value).startswith("PRIOR"):
        return "PRIOR"
    return None


def _find_total_row(
    rows: list[list[Any]], start_row: int, label_col: int, one_year_col: int
) -> int | None:
    for row in range(start_row, min(len(rows), start_row + 20) + 1):
        if _label(_get(rows, row, label_col)) in ("TOTAL", "TOTALS"):
            return row
        if one_year_col and _label(_get(rows, row, one_year_col)) in ("TOTAL", "TOTALS"):
            return row
    return None


def _extract_triangle(
    rows: list[list[Any]],
    title: str,
    vintage: int,
    source_file: str,
    source_sheet: str,
    kind: str,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    title_location = _find_label(rows, title)
    if title_location is None:
        raise ValueError(f"Missing required {kind} Schedule P block")
    title_row, title_col = title_location
    label_col = title_col - 1

    eval_header = None
    one_year_col = None
    for row in range(title_row + 1, min(len(rows), title_row + 6) + 1):
        for col in range(title_col, len(rows[row - 1]) + 1):
            if _label(_get(rows, row, col)) == "ONE YEAR":
                eval_header, one_year_col = row, col
                break
        if eval_header is not None:
            break
    if eval_header is None:
        for row in range(title_row + 1, min(len(rows), title_row + 6) + 1):
            year_count = sum(
                _year(_get(rows, row, col)) is not None
                for col in range(label_col + 1, len(rows[row - 1]) + 1)
            )
            if year_count >= 5:
                eval_header = row
                break
    if eval_header is None:
        raise ValueError(f"Missing evaluation-year header in {kind} block")
    if kind == "incurred" and one_year_col is None:
        raise ValueError("Missing One Year header in incurred block")

    eval_years: list[tuple[int, int]] = []
    final_eval_col = one_year_col if one_year_col is not None else len(rows[eval_header - 1]) + 1
    for col in range(label_col + 1, final_eval_col):
        year = _year(_get(rows, eval_header, col))
        if year is not None:
            eval_years.append((year, col))
    if not eval_years:
        raise ValueError(f"No evaluation-year headers found in {kind} block")

    first_data_row = None
    for row in range(eval_header + 1, min(len(rows), eval_header + 5) + 1):
        if _numeric_or_year_label(_get(rows, row, label_col)) == "PRIOR":
            first_data_row = row
            break
    if first_data_row is None:
        raise ValueError(f"Missing PRIOR row in {kind} block")

    total_row = _find_total_row(rows, first_data_row, label_col, eval_years[-1][1])
    next_section_row = next(
        (
            row
            for row in range(first_data_row, len(rows) + 1)
            if any(_label(value).startswith("PART ") for value in rows[row - 1])
        ),
        len(rows) + 1,
    )
    data_end_row = min(total_row or next_section_row, next_section_row)
    parsed_rows: list[tuple[int, int | str, dict[int, float | None]]] = []
    for row in range(first_data_row, data_end_row):
        row_ay = _numeric_or_year_label(_get(rows, row, label_col))
        if row_ay is None:
            continue
        values: dict[int, float | None] = {}
        for eval_year, col in eval_years:
            value = _get(rows, row, col)
            values[eval_year] = None if _label(value) == "XXX" else _number(value)
        parsed_rows.append((row, row_ay, values))

    if not parsed_rows or parsed_rows[0][1] != "PRIOR":
        raise ValueError(f"PRIOR row was not first in {kind} block")
    accident_years = [ay for _, ay, _ in parsed_rows if isinstance(ay, int)]
    expected_ays = list(range(vintage - 9, vintage + 1))
    if accident_years != expected_ays:
        raise ValueError(
            f"{vintage} {kind} accident-year rows are {accident_years}; expected {expected_ays}"
        )

    observations: list[dict[str, Any]] = []
    published: list[dict[str, Any]] = []
    one_year_differences: list[float] = []
    two_year_differences: list[float] = []
    for row, ay, values in parsed_rows:
        for eval_year, col in eval_years:
            value = values[eval_year]
            if value is not None:
                observations.append(
                    {
                        "vintage": vintage,
                        "ay": ay,
                        "eval_year": eval_year,
                        "value": value,
                        "source_file": source_file,
                        "source_sheet": source_sheet,
                        "source_cell": _cell(row, col),
                    }
                )
        if one_year_col is not None:
            pub_1y_raw = _get(rows, row, one_year_col)
            pub_1y = None if _label(pub_1y_raw) == "XXX" else _number(pub_1y_raw)
            two_year_col = one_year_col + 1
            pub_2y_raw = _get(rows, row, two_year_col)
            pub_2y = None if _label(pub_2y_raw) == "XXX" else _number(pub_2y_raw)
        else:
            pub_1y, pub_2y, two_year_col = None, None, None
        published.append(
            {
                "vintage": vintage,
                "ay": ay,
                "one_year": pub_1y,
                "two_year": pub_2y,
                "source_file": source_file,
                "source_sheet": source_sheet,
                "one_year_cell": _cell(row, one_year_col) if one_year_col is not None else "",
                "two_year_cell": _cell(row, two_year_col) if two_year_col is not None else "",
            }
        )
        available_years = [year for year, value in values.items() if value is not None]
        if pub_1y is not None and len(available_years) >= 2:
            latest = max(available_years)
            recomputed = values[latest] - values.get(latest - 1, values[latest])
            one_year_differences.append(recomputed - pub_1y)
        if pub_2y is not None and len(available_years) >= 3:
            latest = max(available_years)
            previous = values.get(latest - 2)
            if previous is not None:
                recomputed_2y = values[latest] - previous
                two_year_differences.append(recomputed_2y - pub_2y)

    total_row_number = total_row
    total_one_year = (
        _number(_get(rows, total_row_number, one_year_col))
        if one_year_col is not None and total_row_number is not None
        else None
    )
    total_two_year = (
        _number(_get(rows, total_row_number, one_year_col + 1))
        if one_year_col is not None and total_row_number is not None
        else None
    )
    total_dev = sum(
        values["one_year"] for values in published if values["one_year"] is not None
    )
    meta = {
        "total_one_year": total_one_year,
        "total_two_year": total_two_year,
        "total_dev_sum_rows": total_dev,
        "total_one_year_cell": (
            _cell(total_row_number, one_year_col)
            if one_year_col is not None and total_row_number is not None
            else ""
        ),
        "total_two_year_cell": (
            _cell(total_row_number, one_year_col + 1)
            if one_year_col is not None and total_row_number is not None
            else ""
        ),
        "one_year_differences": one_year_differences,
        "two_year_differences": two_year_differences,
        "eval_years": [year for year, _ in eval_years],
        "accident_years": accident_years,
    }
    return observations, published, meta


def _extract_premiums(
    rows: list[list[Any]], vintage: int, source_file: str, source_sheet: str
) -> list[dict[str, Any]]:
    incurred_block = _find_label(rows, INCURRED_TITLE)
    section_end = incurred_block[0] if incurred_block else len(rows) + 1
    header_row = None
    for row in range(1, section_end):
        row_values = [_label(value) for value in rows[row - 1]]
        for col in range(len(row_values) - 2):
            if (
                row_values[col].startswith("DIRECT AND ASSUMED")
                and row_values[col + 1].startswith("CEDED")
                and row_values[col + 2].startswith("NET")
            ):
                header_row = row
                da_col = col + 1
                break
        if header_row is not None:
            break
    if header_row is None:
        raise ValueError("Unable to find Direct and Assumed / Ceded / Net premium columns")

    out = []
    for row in range(header_row + 1, section_end):
        raw_label = _get(rows, row, 1)
        if _label(raw_label) in ("TOTAL", "TOTALS"):
            break
        label = _numeric_or_year_label(raw_label)
        if not isinstance(label, int):
            continue
        direct = _number(_get(rows, row, da_col))
        ceded = _number(_get(rows, row, da_col + 1))
        net = _number(_get(rows, row, da_col + 2))
        if direct is None and ceded is None and net is None:
            continue
        out.append(
            {
                "vintage": vintage,
                "ay": label,
                "direct": direct,
                "ceded": ceded,
                "net": net,
                "source_file": source_file,
                "source_sheet": source_sheet,
                "direct_cell": _cell(row, da_col),
                "ceded_cell": _cell(row, da_col + 1),
                "net_cell": _cell(row, da_col + 2),
            }
        )
    return out


def _check(
    vintage: int,
    name: str,
    difference: float,
    tolerance: float,
    detail: str,
    expected: float | None = None,
) -> dict[str, Any]:
    return {
        "vintage": vintage,
        "check": name,
        "difference": difference,
        "tolerance": tolerance,
        "expected": expected,
        "status": "PASS" if abs(difference) <= tolerance else "FAIL",
        "detail": detail,
    }


def extract_vintage(
    path: Path,
    vintage: int,
    source_url: str,
    source_hash: str,
    source_sheet_name: str = "Filed Total",
    ay_overrides: dict[int, int] | None = None,
) -> VintageData:
    sheets = _load_sheets(path)
    if source_sheet_name not in sheets:
        raise ValueError(f"Missing expected aggregate sheet {source_sheet_name!r} in {path.name}")
    rows = sheets[source_sheet_name]
    if ay_overrides:
        rows = [list(row) for row in rows]
        for source_row, accident_year in ay_overrides.items():
            if source_row < 1 or source_row > len(rows):
                raise ValueError(f"AY override row {source_row} is outside {path.name}")
            label_col = next(
                (
                    col
                    for col, value in enumerate(rows[source_row - 1], start=1)
                    if _label(value).startswith("PRIOR") or _year(value) is not None
                ),
                None,
            )
            if label_col is None:
                raise ValueError(f"AY override row {source_row} has no year label in {path.name}")
            rows[source_row - 1][label_col - 1] = accident_year

    incurred, published, incurred_meta = _extract_triangle(
        rows, INCURRED_TITLE, vintage, path.name, source_sheet_name, "incurred"
    )
    paid, _, _ = _extract_triangle(
        rows, PAID_TITLE, vintage, path.name, source_sheet_name, "paid"
    )
    ibnr, _, _ = _extract_triangle(
        rows, IBNR_TITLE, vintage, path.name, source_sheet_name, "ibnr"
    )
    premiums = _extract_premiums(rows, vintage, path.name, source_sheet_name)

    checks = [
        _check(
            vintage,
            "Part 2 published One Year rows",
            max((abs(value) for value in incurred_meta["one_year_differences"]), default=0.0),
            2.0,
            "Largest absolute row difference, recomputed less published ($000)",
        ),
        _check(
            vintage,
            "Part 2 published One Year total",
            incurred_meta["total_dev_sum_rows"] - incurred_meta["total_one_year"],
            5.0,
            "Sum of published row One Year values less published total ($000)",
        ),
        _check(
            vintage,
            "Part 2 recomputed One Year total",
            sum(
                observation["value"]
                - next(
                    (
                        previous["value"]
                        for previous in incurred
                        if previous["vintage"] == observation["vintage"]
                        and previous["ay"] == observation["ay"]
                        and previous["eval_year"] == observation["eval_year"] - 1
                    ),
                    observation["value"],
                )
                for observation in incurred
                if observation["eval_year"] == vintage
                and any(
                    previous["vintage"] == vintage
                    and previous["ay"] == observation["ay"]
                    and previous["eval_year"] == vintage - 1
                    for previous in incurred
                )
            )
            - incurred_meta["total_one_year"],
            5.0,
            "Sum of recomputed current-vintage one-year development less published total ($000)",
        ),
        _check(
            vintage,
            "Part 2 published Two Year rows",
            max((abs(value) for value in incurred_meta["two_year_differences"]), default=0.0),
            2.0,
            "Largest absolute row difference, recomputed less published ($000)",
        ),
    ]
    for premium in premiums:
        if premium["direct"] is not None and premium["ceded"] is not None and premium["net"] is not None:
            checks.append(
                _check(
                    vintage,
                    f"Net premium AY {premium['ay']}",
                    premium["direct"] - premium["ceded"] - premium["net"],
                    2.0,
                    f"Premium cells {premium['direct_cell']}-{premium['ceded_cell']} vs {premium['net_cell']} ($000)",
                )
            )

    published.append(
        {
            "vintage": vintage,
            "ay": "TOTALS",
            "one_year": incurred_meta["total_one_year"],
            "two_year": incurred_meta["total_two_year"],
            "source_file": path.name,
            "source_sheet": source_sheet_name,
            "one_year_cell": incurred_meta["total_one_year_cell"],
            "two_year_cell": incurred_meta["total_two_year_cell"],
        }
    )

    return VintageData(
        vintage=vintage,
        source_file=path.name,
        source_url=source_url,
        source_hash=source_hash,
        source_sheet=source_sheet_name,
        incurred=incurred,
        paid=paid,
        ibnr=ibnr,
        premiums=premiums,
        published_dev=published,
        checks=checks,
    )
